require(shiny)

shinyUI(pageWithSidebar(

  	# Application title
  	headerPanel("LQAS Design"),

  	# Sidebar 
	sidebarPanel(
	h3("Prior Parameters"),
    	numericInput("mean", "Mean:", 0.5),
    	numericInput("sd", "Standard Deviation:", 0.1)
  	),

  	# Show the summary and plot
  	mainPanel(
		tabsetPanel(
     			tabPanel("Summary", h3("Summary of prior"), verbatimTextOutput("Summary")),
			tabPanel("Plot", plotOutput("Plot"))
    		)
  	)
))