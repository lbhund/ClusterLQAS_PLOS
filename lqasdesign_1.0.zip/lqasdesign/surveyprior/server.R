require(shiny)

shinyServer(function(input, output) {

  	design <- reactive({
    		makeprior(mean=input$mean, sd=input$sd)
		
 	})

   	#Generate a plot 
  	output$Plot <- renderPlot({
		designout <- design()
    		plot(designout)
  	})

  	# Generate a summary 
  	output$Summary <- renderPrint({
		designout <- design()
  	  	summary(designout)
  	})
})