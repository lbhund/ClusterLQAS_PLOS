require(shiny)

shinyUI(pageWithSidebar(

  	# Application title
  	headerPanel("LQAS Design"),

  	# Sidebar 
	sidebarPanel(
	h3("Design Parameters"),
    	sliderInput("pl", "Lower Threshold:", 
                min = 0, max = 1, value = 0.3, step= 0.01),
    	sliderInput("pu", "Upper Threshold:", 
                min = 0, max = 1, value = 0.6, step= 0.01),
    	sliderInput("alpha", "Alpha:", 
                min = 0, max = .5, value = 0.1, step= 0.01),
    	sliderInput("beta", "Beta:", 
                min = 0, max = .5, value = 0.1, step= 0.01),
	h3("Evaluation Parameters"),
    	numericInput("pstar", "pstar", 0.5),
    	numericInput("a", "Beta prior - a", 1),
    	numericInput("b", "Beta prior - b", 1)
  	),

  	# Show the summary and plot
  	mainPanel(
		tabsetPanel(
     			tabPanel("Summary", h3("Summary of design"), verbatimTextOutput("Summary")),
			tabPanel("OC Curve", plotOutput("PlotOC")),
			tabPanel("Risk Curve", plotOutput("PlotRisk")),
     			tabPanel("Evaluate - Pstar", 
				h3("Design properties for programmatic threshold pstar with
				respect to specified Beta prior"),
				verbatimTextOutput("EvalPstar")),
     			tabPanel("Evaluate - Grey Region", 
				h3("Design properties for grey region with respect to specified 
				Beta prior"),
				verbatimTextOutput("EvalGrey"))
    		)
  	)
))