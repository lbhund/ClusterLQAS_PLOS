require(shiny)

shinyServer(function(input, output) {

  	design <- reactive({
    		lqas(pl=input$pl, pu=input$pu, alpha=input$alpha, beta=input$beta)
		
 	})

	evalpstar <- reactive({
		tempdesign <- design()
		designeval(n=tempdesign$n, d=tempdesign$rule, pstar=input$pstar, 
			prior=c(input$a, input$b))
	})

	evalgrey <- reactive({
		tempdesign <- design()
		designeval(n=tempdesign$n, d=tempdesign$rule, pl=input$pl, pu=input$pu, 
			prior=c(input$a, input$b))
	})


   	#Generate a plot 
  	output$PlotOC <- renderPlot({
		designout <- design()
    		plot(designout)
  	})
  	output$PlotRisk <- renderPlot({
		designout <- design()
    		plot(designout, pstar=input$pstar)
  	})
  	output$EvalPstar <- renderPrint({
    		evalout <- evalpstar()
		summary(evalout)
  	})
  	output$EvalGrey <- renderPrint({
    		evalout <- evalgrey()
		summary(evalout)
  	})

  	# Generate a summary 
  	output$Summary <- renderPrint({
		designout <- design()
  	  	summary(designout)
  	})
})