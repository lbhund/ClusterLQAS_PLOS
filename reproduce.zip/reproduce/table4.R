
#! SET WORKING DIRECTORY TO WHERE PEZZOLI.R FUNCTIONS ARE STORED !#
setwd("C:/Users/lhund/Dropbox/PROJECTS/LQAS/ClusterPaper/code")

library(lqasdesign)
library(xtable)
source("pezzoli.R")

# define input parameters #

alpha <- .1
beta 	<- .1
m 	<- 10
rho 	<- .1
nsim 	<- 10000

sigfn <- function(rho, p) sqrt(rho*p*(1-p))

# LOW THRESHOLDS #

pl 	<- .55
pu 	<- .7

sigl 	<- sigfn(rho, pl)
sigu 	<- sigfn(rho, pu)

m1  	<- lqas(pl, pu, alpha, beta)
m2  	<- lqaspezzoli(pl, pu, sigl, alpha, beta, m=m, nsim=nsim)
m3  	<- lqaspezzoli(pl, pu, sigu, alpha, beta, m=m, nsim=nsim)
m4 	<- lqascluster(pl, pu, rho=rho, alpha, beta, m=m, nsim=nsim)
m5 	<- lqascluster(pl, pu, rho=rho, alpha, beta, m=m, ess=F, nsim=nsim)


# MIDDLE THRESHOLDS #

pl 	<- .75
pu 	<- .9

sigl 	<- sigfn(rho, pl)
sigu 	<- sigfn(rho, pu)

m6  	<- lqas(pl, pu, alpha, beta)
m7  	<- lqaspezzoli(pl, pu, sigl, alpha, beta, m=m, nsim=nsim)
m8  	<- lqaspezzoli(pl, pu, sigu, alpha, beta, m=m, nsim=nsim)
m9  	<- lqascluster(pl, pu, rho=rho, alpha, beta, m=m, nsim=nsim)
m10 	<- lqascluster(pl, pu, rho=rho, alpha, beta, m=m, ess=F, nsim=nsim)


# HIGH THRESHOLDS #

pl 	<- .9
pu 	<- .95

sigl 	<- sigfn(rho, pl)
sigu 	<- sigfn(rho, pu)

m11 	<- lqas(pl, pu, alpha, beta)
m12 	<- lqaspezzoli(pl, pu, sigl, alpha, beta, m=m, nsim=nsim)
m13 	<- lqaspezzoli(pl, pu, sigu, alpha, beta, m=m, nsim=nsim)
m14 	<- lqascluster(pl, pu, rho=rho, alpha, beta, m=m, nsim=nsim)
m15 	<- lqascluster(pl, pu, rho=rho, alpha, beta, m=m, ess=F, nsim=nsim)


# MAKE TABLE #

makeoutput 	<- function(m){
	out 	<- c(m$n[1], m$rule[1], m$k[1], m$m[1], m$alpha[1], m$beta[1])
	if(is.null(m$k) ==T)
	out 	<- c(m$n[1], m$rule[1], m$n[1], 1, m$alpha[1], m$beta[1])
	return(out)
}

low 	<- rbind(makeoutput(m1),
makeoutput(m2),
makeoutput(m3),
makeoutput(m4),
makeoutput(m5))

row.names(low) 	<- c("L: SRS", "L: Pezzoli L", "L: Pezzoli U", "L: Hund", "L: Hedt")
colnames(low) 	<- c("n", "d", "k", "m", "alpha", "beta")

middle 	<- rbind(makeoutput(m6),
makeoutput(m7),
makeoutput(m8),
makeoutput(m9),
makeoutput(m10))

row.names(middle) <- c("M: SRS", "M: Pezzoli L", "M: Pezzoli U", "M: Hund", "M: Hedt") 
colnames(middle) 	<- colnames(low) 

high 	<- rbind(makeoutput(m11),
makeoutput(m12),
makeoutput(m13),
makeoutput(m14),
makeoutput(m15))

row.names(high) 	<- c("H: SRS", "H: Pezzoli L", "H: Pezzoli U", "H: Hund", "H: Hedt")
colnames(high) 	<- colnames(middle) 

xtable(rbind(low, middle, high), digits=c(0, 0,0,0,0,3, 3))




