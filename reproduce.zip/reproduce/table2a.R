
#! CHANGE TO DIRECTORY WHERE PEZZOLI.R IS STORED !#
setwd("C:/Users/lhund/Dropbox/PROJECTS/LQAS/ClusterPaper/code")

set.seed(6)

library(lqasdesign)
library(xtable)
library(VGAM)
source("pezzoli.R")

# input parameters for each of the 3 couplets #
nsim 	<- 10000
sd	<- .1

dlist <- data.frame(m  = c(10, 10, 6),
			  k  = c(6, 6, 33), 
		        pl = c(.55, .75, .9), 
		        pu = c(.7, .9, .95), 
			  d  = c(38, 50, 33*6 - 13 - 1))

iccfn <- function(sd, p) sd^2/(p*(1-p))
deff 	<- function(m, rho) 1 + (m-1)*rho

# define output matrices #

mata 		<- matrix(NA, nrow=3, ncol=3)
mata 		<- as.data.frame(mata)
matb 		<- mata
colnames(mata) 	<- c("a1", "a2", "a3")
colnames(matb) 	<- c("b1", "b2", "b3")
row.names(mata) <- row.names(matb) <- c("binom", "beta", "qbinr")

# run simulation for each of the 3 couplets #
for(jj in 1:3){

	m			<- dlist$m[jj]
	k			<- dlist$k[jj]
	iccl			<- iccfn(sd, dlist$pl[jj])
	iccu			<- iccfn(sd,dlist$pu[jj])
	deffl			<- deff(m, iccl)
	deffu			<- deff(m, iccu)
	pl			<- dlist$pl[jj]
	pu			<- dlist$pu[jj]
	dd			<- dlist$d[jj]

	bino 			<- sapply(1:nsim, function(kk) sum(rbinom(k, m, prob=pezzoli(pl, sd, k))))
	matb[1,jj] 		<- mean(ifelse(bino  > dd, 1, 0))
	bino 			<- sapply(1:nsim, function(kk) sum(rbinom(k, m, prob=pezzoli(pu, sd, k))))
	mata[1,jj]  	<- mean(ifelse(bino <= dd, 1, 0))
	
	beta 			<- sapply(1:nsim, function(kk) sum(rbetabinom(k, m, pl, iccl)))
	matb[2,jj] 		<- mean(ifelse(beta  > dd, 1, 0))
	beta 			<- sapply(1:nsim, function(kk) sum(rbetabinom(k, m, pu, iccu)))
	mata[2,jj]   	<- mean(ifelse(beta <= dd, 1, 0))

	qbin 			<- sapply(1:nsim, function(kk) rbinom(1, round(k*m/deffl),pl))
	matb[3,jj]  	<- mean(ifelse(qbin  > dd/deffl, 1, 0))
	qbin 			<- sapply(1:nsim, function(kk) rbinom(1, round(k*m/deffu), pu))
	mata[3,jj]  	<- mean(ifelse(qbin <= dd/deffu, 1, 0))

}

xtable(cbind(mata[,1], matb[,1],mata[,2], matb[,2], mata[,3], matb[,3]), digits=c(0,3, 3, 3,3,3,3))



