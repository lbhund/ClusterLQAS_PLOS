
#! SET DIRECTORY TO WHERE PEZZOLI.R FUNCTIONS ARE STORED !#
setwd("C:/Users/lhund/Dropbox/PROJECTS/LQAS/ClusterPaper/code/")
source("pezzoli.R")

#! SET DIRECTORY TO WHERE YOU WANT PICTURES WRITTEN !#
setwd("C:/Users/lhund/Dropbox/PROJECTS/LQAS/ClusterPaper/pics/")

set.seed(4)
library(foreign)

#! READ IN DATASET, SPECIFYING PATH TO DATA !#
dat 		<- read.dta("C:/Users/lhund/Dropbox/PROJECTS/LQAS/ClusterPaper/minetti.dta")

# input parameters # 
nsim 		<- 5000
m 		<- 10
k 		<- 6 
d 		<- 50
pdat 		<- data.frame(phat=c(.75, .9))

dat$phat 	<- dat$coverage/100
dat$sigma 	<- sqrt(dat$icc*dat$phat*(1-dat$phat))
dat$rho 	<- dat$icc
pvec 		<- seq(from=min(dat$phat), to = max(dat$phat), by = .02)

# loess line for estimated standard deviation sigma and estimated icc rho #
sigmod 	<- loess(sigma ~ phat, data=dat)
rhomod	<- loess(rho ~ phat, data=dat)


### CALCULATE OC CURVES ###

# Fix sd as mean sd across all locations#
sd 	<- mean(dat$sigma)
# get entire oc curve #
ocsd 	<- sapply(pvec, function(pp) 
	mean(sapply(1:nsim, function(ii) 
	ifelse(sum(rbinom(k, m, p=pezzoli(pp, sd, k))) <= d, 1, 0))))
# get alpha and beta only #
absd 	<- sapply(pdat$phat, function(pp) 
	mean(sapply(1:nsim, function(ii) 
	ifelse(sum(rbinom(k, m, p=pezzoli(pp, sd, k))) <= d, 1, 0))))

# Allow sd to vary as a function of p based on loess fit #
newdat	<- data.frame(pvec)
colnames(newdat)	<- "phat"
newdat$newsigs 	<- predict(sigmod, newdat)
newdat$newsigs[which(newdat$newsigs < 0)] 	<- 0
pdat$newsigs 	<- predict(sigmod, pdat)
ocsdemp 	<- sapply(1:nrow(newdat), function(pp) 
			mean(sapply(1:nsim, function(ii) 
			ifelse(sum(rbinom(k, m, p=pezzoli(newdat$phat[pp], newdat$newsigs[pp], k))) <= d, 1, 0))))
absdemp 	<- sapply(1:nrow(pdat), function(pp) 
			mean(sapply(1:nsim, function(ii) 
			ifelse(sum(rbinom(k, m, p=pezzoli(pdat$phat[pp], pdat$newsigs[pp], k))) <= d, 1, 0))))

# Fix icc at the mean value of rho #
sd 		<- sqrt(mean(dat$rho)*pvec*(1-pvec))
ocrho 	<- sapply(1:length(pvec), function(pp) 
			mean(sapply(1:nsim, function(ii) 
			ifelse(sum(rbinom(k, m, p=pezzoli(pvec[pp], sd[pp], k))) <= d, 1, 0))))
abrho 	<- sapply(1:length(pdat$phat), function(pp) 
			mean(sapply(1:nsim, function(ii) 
			ifelse(sum(rbinom(k, m, p=pezzoli(pdat$phat[pp], sd[pp], k))) <= d, 1, 0))))

# Estimate rho as a function of p based on loess fit #
newdat 	<- data.frame(pvec)
colnames(newdat) 	<- "phat"
newdat$newrhos 	<- predict(rhomod, newdat)
newdat$newrhos[which(newdat$newrhos < 0)] 	<- 0
newdat$newsigs 	<- sqrt(newdat$newrhos*newdat$phat*(1-newdat$phat))
pdat$newrhos	<- predict(rhomod, pdat)
pdat$newsigrhos	<- sqrt(pdat$newrhos*pdat$phat*(1-pdat$phat))
ocrhoemp 	<- sapply(1:nrow(newdat), function(pp) 
	mean(sapply(1:nsim, function(ii) 
	ifelse(sum(rbinom(k, m, p=pezzoli(newdat$phat[pp], newdat$newsigs[pp], k))) <= d, 1, 0))))
abrhoemp 	<- sapply(1:nrow(pdat), function(pp) 
	mean(sapply(1:nsim, function(ii) 
	ifelse(sum(rbinom(k, m, p=pezzoli(pdat$phat[pp], pdat$newsigrhos[pp], k))) <= d, 1, 0))))


### MAKE PLOTS ###

# plot estimated rho and sigma as a function of p with loess smooth #
file <- "figure3.tif"
tiff(filename=file, width=12, height=12, units="in", res=300, compression="lzw")
par(mfrow=c(2,2), mar=c(4.5, 5.5, 2, .2))
plot(dat$phat, dat$sigma, xlab="p", ylab=expression(hat(sigma)), cex=1.5, cex.lab=2, cex.axis=1.5)
lines(dat$phat, sigmod$fitted, lwd=2)
plot(dat$phat, dat$rho, xlab="p", ylab=expression(hat(rho)), cex=1.5, cex.lab=2, cex.axis=1.5)
lines(dat$phat, rhomod$fitted, lwd=2)

# plot estimated OC curves based on fixed or varying rho and sigma #
plot(pvec, ocsd, xlab="p", ylab="P(X<=d)", type="l", lty=1, cex=2, cex.lab=2, cex.axis=1.5, lwd=2)
lines(pvec, ocsdemp, lty=2, lwd=2)
abline(v=.75, lty=3)
abline(v=.9, lty=3)
alphabeta 		<- round(rbind(absd, absdemp), digits=3)
alphabeta[,1]	<- 1 - alphabeta[,1]
legendtext <- c(bquote(alpha== .(alphabeta[1,2])), 
bquote(beta==.(alphabeta[1,1])),
bquote(alpha==.(alphabeta[2,2])),
bquote(beta==.(alphabeta[2,1])))
legend("topright", lty=c(1,1, 2, 2), as.expression(legendtext), 
col=c("black", "white","black", "white"), cex=1.2)

plot(pvec, ocrho, xlab="p", ylab="P(X<=d)", type="l", lty=1, cex=2, cex.lab=2, cex.axis=1.5, lwd=2)
lines(pvec, ocrhoemp, lty=2, lwd=2)
abline(v=.75, lty=3)
abline(v=.9, lty=3)
alphabeta 		<- round(rbind(abrho, abrhoemp), digits=3)
alphabeta[,1]	<- 1 - alphabeta[,1]
legendtext <- c(bquote(alpha== .(alphabeta[1,2])), 
bquote(beta==.(alphabeta[1,1])),
bquote(alpha==.(alphabeta[2,2])),
bquote(beta==.(alphabeta[2,1])))
legend("topright", lty=c(1,1, 2, 2), as.expression(legendtext), 
col=c("black", "white","black", "white"), cex=1.2)
dev.off()




