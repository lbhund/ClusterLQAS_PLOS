
#! CHANGE DIRECTORY TO WHEREEVER FILE SHOULD BE WRITTEN, e.g. C:\My Documents\Dropbox\... !#
setwd("C:/Users/lhund/Dropbox/PROJECTS/LQAS/ClusterPaper/pics")

library(lqasdesign)

# specify initial parameters #
pl 	<- .5
pm 	<- .7
pu 	<- .9
sd	<- .1

pvec 	<- seq(.001,.999, length=100)

# convert sd to icc #
iccfn <- function(sd, p) sd^2/(p*(1-p))
iccl 	<- iccfn(sd, pl)
iccu 	<- iccfn(sd, pu)
iccm 	<- iccfn(sd, pm)

# convert icc and p to a and b for beta distribution #
abfn <- function(icc, p) {
	a 	<- (1/icc - 1)/((1-p)/p + 1)
	b 	<- a*(1-p)/p
	return(c(a,b))
}

abl 	<- abfn(iccl, pl)
abu 	<- abfn(iccu, pu)
abm 	<- abfn(iccm, pm)

# define function to plot binomial-scaled histogram, adapted from https://answers.yahoo.com/question/index?qid=20130719044527AA3x3XM

binomial.histogram <- function(n, prob = 0.5, col = "white",...) { 
  bin.min 	<- 0 
  bin.max 	<- n 
  bin.range <- bin.min : bin.max 
  my.binomial 	<- NULL 
  my.binomial$breaks 	<- ((bin.min - 0.5) : (bin.max + 0.5))/n
  my.binomial$counts 	<- dbinom(bin.range, bin.max, prob) 
  attr(my.binomial, "class") 	<- "histogram" 
  col.border 	<- col 
  col.border["white" == col] 	<- "black" 
  plot(my.binomial, border = col.border, col = col, ylab="", 
	xlab = "p", yaxt='n', main="", cex=1.5, cex.axis=1.5, cex.lab=1.5,...) 
  return(my.binomial) 
}

dplvec  <- dbeta(pvec, abl[1], abl[2])
dpuvec  <- dbeta(pvec, abu[1], abu[2])
dpmvec  <- dbeta(pvec, abm[1], abm[2])

# write picture to file #
file 	<- "fig1.tif"
tiff(filename=file, width=12, height=4, units="in", res=300)
par(mfrow=c(1,3))
#panel 1
a 	<- binomial.histogram(1/iccl, prob=.5)
lines(pvec, dplvec*max(a$counts)/max(dplvec), lty=2)
legend("topleft", lty=c(1,2), c("Binomial", "Beta"), cex=1.5)
#panel 2
a 	<- binomial.histogram(1/iccm, prob=.7)
lines(pvec, dpmvec*max(a$counts)/max(dpmvec), lty=2)
#panel 3
a 	<- binomial.histogram(1/iccu, prob=.9)
lines(pvec, dpuvec*2*max(a$counts)/max(dpuvec), lty=2)

dev.off()