
#! SET WORKING DIRECTORY TO WHERE PEZZOLI.R FUNCTIONS ARE STORED !#
setwd("C:/Users/lhund/Dropbox/PROJECTS/LQAS/ClusterPaper/code")

set.seed(5)

library(lqasdesign)
library(xtable)
source("pezzoli.R")

# define input parameters #
alpha <- .1
beta 	<- .1
m 	<- 10
sd 	<- .1
nsim 	<- 10000
iccfn <- function(sd, p) sd^2/(p*(1-p))

# LOW THRESHOLDS #

pl 	<- .55
pu 	<- .7

iccl 	<- iccfn(sd, pl)
iccu 	<- iccfn(sd, pu)

m1  	<- lqas(pl, pu, alpha, beta)
m2  	<- lqaspezzoli(pl, pu, sd, alpha, beta, m=m, nsim=nsim)
m3  	<- lqascluster(pl, pu, rho=iccl, alpha, beta, m=m, nsim=nsim)
m4 	<- lqascluster(pl, pu, rho=iccl, alpha, beta, m=m, ess=F, nsim=nsim)
m5 	<- lqascluster(pl, pu, rho=iccu, alpha, beta, m=m, nsim=nsim)
m6 	<- lqascluster(pl, pu, rho=iccu, alpha, beta, m=m, ess=F, nsim=nsim)

# MIDDLE THRESHOLDS #

pl 	<- .75
pu 	<- .9

iccl 	<- iccfn(sd, pl)
iccu 	<- iccfn(sd, pu)

m7  	<- lqas(pl, pu, alpha, beta)
m8  	<- lqaspezzoli(pl, pu, sd, alpha, beta, m=m, nsim=nsim)
m9  	<- lqascluster(pl, pu, rho=iccl, alpha, beta, m=m, nsim=nsim)
m10 	<- lqascluster(pl, pu, rho=iccl, alpha, beta, m=m, ess=F, nsim=nsim)
m11 	<- lqascluster(pl, pu, rho=iccu, alpha, beta, m=m, nsim=nsim)
m12 	<- lqascluster(pl, pu, rho=iccu, alpha, beta, m=m, ess=F, nsim=nsim)

# HIGH THRESHOLDS #

pl 	<- .9
pu 	<- .95

iccl 	<- iccfn(sd, pl)
iccu 	<- iccfn(sd, pu)

m13 	<- lqas(pl, pu, alpha, beta)
m14 	<- lqaspezzoli(pl, pu, sd, alpha, beta, m=m, nsim=nsim)
m15 	<- lqascluster(pl, pu, rho=iccl, alpha, beta, m=m, nsim=nsim)
m16 	<- lqascluster(pl, pu, rho=iccl, alpha, beta, m=m, ess=F, nsim=nsim)
m17 	<- lqascluster(pl, pu, rho=iccu, alpha, beta, m=m, nsim=nsim)
m18 	<- lqascluster(pl, pu, rho=iccu, alpha, beta, m=m, ess=F, nsim=nsim)


# MAKE TABLE #

makeoutput 	<- function(m){
	out 	<- c(m$n[1], m$rule[1], m$k[1], m$m[1], m$alpha[1], m$beta[1])
	if(is.null(m$k) ==T)
	out 	<- c(m$n[1], m$rule[1], m$n[1], 1, m$alpha[1], m$beta[1])
	return(out)
}

low 	<- rbind(makeoutput(m1),
makeoutput(m2),
makeoutput(m3),
makeoutput(m4),
makeoutput(m5),
makeoutput(m6))

row.names(low) 	<- c("L: SRS", "L: Pezzoli", "L: Hund, L", "L: Hedt, L", "L: Hund, U", "L: Hedt, U")
colnames(low) 	<- c("n", "d", "k", "m", "alpha", "beta")

middle 	<- rbind(makeoutput(m7),
makeoutput(m8),
makeoutput(m9),
makeoutput(m10),
makeoutput(m11),
makeoutput(m12))

row.names(middle) <- c("M: SRS", "M: Pezzoli", "M: Hund, L", "M: Hedt, L", "M: Hund, U", "M: Hedt, U")
colnames(middle) 	<- colnames(low) 

high 	<- rbind(makeoutput(m13),
makeoutput(m14),
makeoutput(m15),
makeoutput(m16),
makeoutput(m17),
makeoutput(m18))

row.names(high) 	<- c("H: SRS", "H: Pezzoli", "H: Hund, L", "H: Hedt, L", "H: Hund, U", "H: Hedt, U")
colnames(high) 	<- colnames(middle) 

xtable(rbind(low, middle, high), digits=c(0, 0,0,0,0,3, 3))




