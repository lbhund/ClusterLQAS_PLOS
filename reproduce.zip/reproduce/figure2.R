
#! CHANGE TO DIRECTORY WHERE YOU WANT TO SAVE PICTURES !#
setwd("C:/Users/lhund/Dropbox/PROJECTS/LQAS/ClusterPaper/pics")

# input parameters #
pl 	<- .75
pu 	<- .9
sd 	<- 0.1
k 	<- 6
m 	<- 10
d 	<- 50
pvec 	<- seq(.2,.999, length=100)

########################################## 
####### CODE FOR SD FIGURE ############### 
########################################## 

# convert sd to icc #
iccfn <- function(sd, p) sd^2/(p*(1-p))
iccl 	<- iccfn(sd, pl)
iccu 	<- iccfn(sd, pu)

# convert icc and p to a and b for beta distribution #
abfn <- function(icc, p) {
	a <- (1/icc - 1)/((1-p)/p + 1)
	b <- a*(1-p)/p
	return(c(a,b))
}

ab 	<- abfn(iccl, pl)

absdl <- abfn(iccl, pl)
absdu <- abfn(iccu, pu)

abll 	<- abfn(iccl, pl)
ablu 	<- abfn(iccl, pu)

abul 	<- abfn(iccu, pl)
abuu 	<- abfn(iccu, pu)

#get beta densities
dnplvec  	<- dbeta(pvec, absdl[1], absdl[2])
dnpuvec  	<- dbeta(pvec, absdu[1], absdu[2])

dbpllvec 	<- dbeta(pvec, abll[1], abll[2])
dbpluvec 	<- dbeta(pvec, ablu[1], ablu[2])
	
dbpulvec 	<- dbeta(pvec, abul[1], abul[2])
dbpuuvec 	<- dbeta(pvec, abuu[1], abuu[2])

# make plots #
ylim1	<- ylim2 <- ylim3 <- 15

file 	<- paste("sd1_", 100*pl, "_", 100*pu, ".png", sep="")
png(filename=file, width=1.6*480)
par(mai=c(1.2, 1.8, .1, .01))
plot(pvec, dnpuvec, type="l", xlab="p", ylab="density",
 cex=3, cex.lab=3, cex.axis=3, lwd=2, ylim=c(0, ylim1))
lines(pvec, dnplvec, lwd=2)
legend("topleft", expression(sigma==.1), cex=2.5)
abline(v=pu, lty=2)
abline(v=pl, lty=2)
dev.off()

file 	<- paste("sd2_", 100*pl, "_", 100*pu, ".png", sep="")
png(filename=file, width=1.6*480)
par(mai=c(1.2, 1.5, .1, .01))
plot(pvec, dbpllvec, type="l", ylim=c(0,ylim2), xlab="p", 
ylab="", cex=3, cex.lab=3, cex.axis=3, lwd=2)
lines(pvec, dbpluvec, type="l", lwd=2)
legend("topleft", legend=bquote(rho[l] == .(round(iccl, digits=2))), cex=2.5)
abline(v=pu, lty=2)
abline(v=pl, lty=2)
dev.off()

file 	<- paste("sd3_", 100*pl, "_", 100*pu, ".png", sep="")
png(filename=file, width=1.6*480)
par(mai=c(1.2, 1.5, .1, .01))
plot(pvec, dbpulvec, type="l", ylim=c(0,ylim3), 
xlab="p", ylab="", cex=3, cex.lab=3, cex.axis=3, lwd=2)
lines(pvec, dbpuuvec, type="l", lwd=2)
legend("topleft", legend=bquote(rho[u] == .(round(iccu, digits=2))), cex=2.5)
abline(v=pu, lty=2)
abline(v=pl, lty=2)
dev.off()

